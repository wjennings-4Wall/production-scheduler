# Design notes

History of decisions, newest last. Links to the live app and crew pages are kept in the claude.ai project "Production Scheduling", not here.

## October 2026: first build

- Data is shared and stored with the published page (`db` collections `projects`, `tasks`, `views`, `docs`).
- Times are "floating" local times (`YYYY-MM-DDTHH:MM`), entered in the venue's local time with no time zone attached.
- Each show, shoot or install is a project. Tasks are tagged with people, departments, equipment and free tags.
- Views: Gantt (hours/days/weeks), Calendar (month/week/day hour grid, click to add, drag to move or resize in 15-minute steps) and List.
- Saved views get a shareable link (`#view-<id>`). Viewers can change tabs and filters on their own screen. Their changes are remembered in their browser and never alter the saved view.
- Export: a calendar CSV that imports into Outlook and Google Calendar, and copy-to-clipboard iCalendar text. A direct `.ics` download isn't allowed by the artifact sandbox.
- Branding applied from the 4Wall Brand Guidelines (2021).
- Documents tab: PDFs and images uploaded as artifact assets (20 MB max), plus links. It follows the project and department filters, and documents with no departments show for everyone on the project.
- Locations became a tag list (`locations[]`) instead of a single text field. Project venues are suggested as locations.
- Outside guests invited by email get a view-only page.

## November 2026

- Crew snapshots: one read-only page per project with its data built in, made by `scripts/build_snapshot.py`. Sending the live app isn't enough to keep a crew to one project, because anyone with access can clear the filters.
- 4Wall's organization settings turn off public links for artifacts, even for pages without a database or uploads. Outside crew need an email invite.
- "+ Task" defaults to the times of the viewer's most recently saved task. If there isn't one, it uses the most recently updated task, then 09:00 today. Clicking an empty calendar slot still uses that slot's time.
- Filter lists only show people, departments, locations, equipment, tags and statuses used by tasks in the selected projects. The Projects filter and button are hidden for view-only people when there's only one project.

## Ideas not built yet

- Copy uploaded documents into crew snapshots.
- Location tags on documents, so a venue's ground plan only shows for that venue.
- A storage backend that lets the app run outside claude.ai.
- New tasks starting when the previous one ends (for back-to-back calls).
