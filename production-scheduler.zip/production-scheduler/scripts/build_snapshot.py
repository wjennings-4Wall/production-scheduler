"""Build a read-only public snapshot of the Production Scheduler.

Usage: python3 build_snapshot.py LIVE_HTML DATA_DIR OUT_HTML SNAPSHOT_URL "16 Nov 2026" [FILES_JSON] [--project "Name or id"]
- --project: build a snapshot of ONE project only. Other projects, their tasks, docs and views are left out,
  so people, departments, locations etc. that only appear on other projects never reach the page.
- LIVE_HTML: the live page as saved by Artifact read (full document).
- DATA_DIR: ArtifactData out_dir with projects/ tasks/ views/ docs/ JSON files.
- FILES_JSON (optional): {"<assetId>": "files/<name>.pdf", ...} for documents published alongside.
Projects named "Example: ..." and their tasks/docs are left out.
"""
import json, os, re, sys, glob

argv = sys.argv[1:]
only = None
if "--project" in argv:
    i = argv.index("--project"); only = argv[i + 1]; del argv[i:i + 2]
live, data_dir, out, snap_url, asof = argv[:5]
files_map = json.load(open(argv[5])) if len(argv) > 5 else {}

s = open(live, encoding="utf-8").read()
if "<body>" in s:
    s = s[s.index("<body>") + len("<body>"): s.rindex("</body>")]

def load(col):
    rows = []
    for f in sorted(glob.glob(os.path.join(data_dir, col, "*.json"))):
        d = json.load(open(f, encoding="utf-8"))
        d["id"] = os.path.splitext(os.path.basename(f))[0]
        rows.append(d)
    return rows

projects = [p for p in load("projects") if not p.get("name", "").startswith("Example:")]
if only:
    projects = [p for p in projects if p["id"] == only or p.get("name", "").lower() == only.lower()]
    assert len(projects) == 1, "project not found: " + only
keep = {p["id"] for p in projects}
tasks = [t for t in load("tasks") if t.get("projectId") in keep]
for t in tasks:
    if not isinstance(t.get("locations"), list):
        t["locations"] = [t["location"]] if t.get("location") else []
    for k in ("location", "updatedAt"):
        t.pop(k, None)
docs = [d for d in load("docs") if d.get("projectId") in keep and (d.get("kind") == "link" or d.get("assetId") in files_map)]
views = []
for v in load("views"):
    f = v.get("filters", {})
    orig = f.get("project", [])
    f["project"] = [p for p in orig if p in keep]
    if only:
        if not f["project"]:
            continue  # view is about another project, or spans all projects
        f["project"] = []  # single-project page: no project filter needed
        # drop filter values that don't occur in this project
        for k in ("people", "departments", "locations", "equipment", "tags"):
            used = {x for t in tasks for x in t.get(k, [])}
            f[k] = [x for x in f.get(k, []) if x in used]
    views.append(v)

snap = {"asof": asof, "projects": projects, "tasks": tasks, "docs": docs, "views": views, "files": files_map}
blob = json.dumps(snap, ensure_ascii=False).replace("</", "<\\/")

def R(a, b, n=1):
    global s
    c = s.count(a)
    assert c == n, (c, a[:80])
    s = s.replace(a, b)

title = (projects[0]["name"] + " Schedule") if only else "Production Schedule Snapshot"
R('<title>Production Scheduler</title>', '<title>%s</title>' % title.replace("&", "&amp;").replace("<", "&lt;"))
s = re.sub(r'const ARTIFACT_URL = "[^"]*";', 'const ARTIFACT_URL = %s;\nconst SNAPSHOT = %s;\nconst blobUrl = id => SNAPSHOT.files[id] || "";' % (json.dumps(snap_url), blob), s, count=1)
R('src="/_blob/${esc(sel.assetId)}"', 'src="${esc(blobUrl(sel.assetId))}"')
R('fetch("/_blob/"+d.assetId)', 'fetch(blobUrl(d.assetId))', 2)

# Banner: always show a snapshot strip
R('''  if(!v){ el.hidden=true; return; }''',
  '''  if(!v){ el.hidden=false; el.innerHTML=`<span>Read-only schedule snapshot</span><b>Updated ${esc(SNAPSHOT.asof)}</b><span class="note" style="color:var(--fg)">Switch views with the tabs above and use the filters to find the tasks that apply to you.</span>`; return; }''')
R('<span>Shared view</span><b>${esc(v.name)}</b>', '<span>Snapshot ${esc(SNAPSHOT.asof)} · view</span><b>${esc(v.name)}</b>')

# Share modal note
s = re.sub(r'<p class="note">A saved link opens on the tab you were viewing.*?</p>',
           '<p class="note">This is a read-only snapshot. Each link opens it on a saved view; anyone can then switch tabs and change filters on their own screen.</p>', s, count=1, flags=re.S)

# Boot: embedded data, no database
a = s.index("/* ---------- boot ---------- */")
b = s.index("</script>", a)
s = s[:a] + '''/* ---------- boot (snapshot) ---------- */
S.canWrite=false; S.assets=null; S.db=null;
S.projects=SNAPSHOT.projects; S.tasks=SNAPSHOT.tasks; S.docs=SNAPSHOT.docs; S.views=SNAPSHOT.views;
S.loaded={p:true,t:true,v:true};
render(); checkHash();
''' + s[b:]

open(out, "w", encoding="utf-8").write(s)
print("projects", len(projects), "tasks", len(tasks), "docs", len(docs), "views", len(views))
